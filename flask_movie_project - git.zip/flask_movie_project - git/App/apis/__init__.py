from App.apis.movie_list import movie_list_api


def init_api(app):
    movie_list_api.init_app(app)