from flask_restful import Api

from App.apis.movie_list.movie_list_api import MovieListResource

movie_list_api = Api(prefix='/movie')
movie_list_api.add_resource(MovieListResource, '/list')
