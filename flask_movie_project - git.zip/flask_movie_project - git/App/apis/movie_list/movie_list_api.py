
from flask_restful import Resource

from App.models.movies import Movie



class MovieListResource(Resource):
    def get(self):
        data={
            "msg":"hello restful呵呵 wjl"
        }
        return data
