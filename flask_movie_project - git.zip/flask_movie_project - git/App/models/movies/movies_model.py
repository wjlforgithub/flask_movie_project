from App.ext import db
from App.models import BaseModel


class Movie(BaseModel):
    __tablename__ = "movies"
    m_name = db.Column(db.String(128))
    link = db.Column(db.String(255), unique=True)
    cover = db.Column(db.String(64), unique=True)
    detail_image = db.Column(db.String(64), unique=True)
    description = db.Column(db.String(255))
    cover_name = db.Column(db.String(64))
    # 上架时间
    film_time = db.Column(db.DATE)
