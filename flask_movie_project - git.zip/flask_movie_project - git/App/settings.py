import os

BASE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)))


# 配置基类
class Config(object):
    DEBUG = False
    TESTING = False
    SQLALCHEMY_TRACK_MODIFICATIONS = True


# 开发环境配置
def get_db_uri(dbinfo):
    engine = dbinfo.get("ENGINE") or "sqlite"
    driver = dbinfo.get("DRIVER") or "sqlite"
    user = dbinfo.get("USER") or ""
    password = dbinfo.get("PASSWORD") or ""
    host = dbinfo.get("HOST") or ""
    port = dbinfo.get("PORT") or ""
    name = dbinfo.get("NAME") or ""

    return "{}+{}://{}:{}@{}:{}/{}".format(engine, driver, user, password, host, port, name)


class DevelopConfig(Config):
    DEBUG = True
    dbinfo = {
        "ENGINE": "mysql",
        "DRIVER": "pymysql",
        "USER": "root",
        "PASSWORD": "wjl1314",
        "HOST": "localhost",
        "PORT": "3306",
        "NAME": "flask_2019"
    }
    SQLALCHEMY_DATABASE_URI = get_db_uri(dbinfo)


# 测试环境配置
class TestConfig(Config):
    TESTING = True
    dbinfo = {

        "ENGINE": "mysql",
        "DRIVER": "pymysql",
        "USER": "root",
        "PASSWORD": "wjl1314",
        "HOST": "localhost",
        "PORT": "3306",
        "NAME": "flask_2019"
    }
    SQLALCHEMY_DATABASE_URI = get_db_uri(dbinfo)


# 演示环境配置
class StagingConfig(Config):
    dbinfo = {

        "ENGINE": "mysql",
        "DRIVER": "pymysql",
        "USER": "root",
        "PASSWORD": "wjl1314",
        "HOST": "localhost",
        "PORT": "3306",
        "NAME": "flask_2019"
    }
    SQLALCHEMY_DATABASE_URI = get_db_uri(dbinfo)


# 生产环境配置
class ProductConfig(Config):
    dbinfo = {

        "ENGINE": "mysql",
        "DRIVER": "pymysql",
        "USER": "root",
        "PASSWORD": "wjl1314",
        "HOST": "localhost",
        "PORT": "3306",
        "NAME": "flask_2019"
    }
    SQLALCHEMY_DATABASE_URI = get_db_uri(dbinfo)


envs = {
    "develop": DevelopConfig,
    "testing": TestConfig,
    "staging": StagingConfig,
    "product": ProductConfig,
    "default": DevelopConfig
}
