from App.views.app_blue import blue


def init_view(app):
    app.register_blueprint(blue)