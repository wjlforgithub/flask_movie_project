from flask import Blueprint, render_template, request

from App.models.movies import Movie

blue = Blueprint("blue", __name__)


@blue.route("/")
def home():
    return render_template("base.html")



@blue.route("/index")
def index():
    # blueprint返回一个index.html
    page = request.args.get("page", 1, type=int)

    per_page = request.args.get('per_page', 50, type=int)

    movies = Movie.query.offset(per_page * (page - 1)).limit(per_page)
    for m in movies:
        data = m.description[0:100] + "..." + m.description[300:-16]
    return render_template('index.html', movies=movies, data=data)


@blue.route("/music")
def music():
    return render_template('music.html')


@blue.route("/index3")
def index3():
    # blueprint返回一个index.html
    page = request.args.get("page", 1, type=int)

    per_page = request.args.get('per_page', 8, type=int)

    movies = Movie.query.offset(per_page * (page - 1)).limit(per_page)

    return render_template('index3.html', movies=movies)


@blue.route('/getmovieswithpage/')
def get_movies_with_page():
    pagination = Movie.query.paginate()

    per_page = request.args.get('per_page', 8, type=int)

    return render_template('index.html', pagination=pagination, per_page=per_page)
