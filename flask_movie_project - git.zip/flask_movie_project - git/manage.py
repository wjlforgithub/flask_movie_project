import os
from flask_migrate import MigrateCommand
from flask_script import Manager
from App import create_app

# 根据不同系统环境变量切换不同配置=
env = os.environ.get("FLASK_ENV", "develop")
# 初始化app
app = create_app(env)
# manager的管理工具,这样flask可以像django一样使用命令行
manager = Manager(app=app)
manager.add_command('db', MigrateCommand)

if __name__ == '__main__':
    manager.run()
